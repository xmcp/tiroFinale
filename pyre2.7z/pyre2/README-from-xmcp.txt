This is the local copy of https://github.com/axiak/pyre2/pull/33, a Python3-friendly version of `pyre2`.
The `re2.lib` compiled from https://code.google.com/p/re2win using VC++ 2010 is attached for your convinience.

If you are experiencing Python3-related bugs or MinGW-related bugs during installing `re2`, try this one.

Modified by @xmcp.

Setup Instruction:

- copy `re2.lib` to `(PYTHON_ROOT)/libs`
- `cd package_root`
- `setup.py install`
- test: `py -3 -c "import re2"`
