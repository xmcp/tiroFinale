#!/usr/bin/env python
import io
import os
import re
import sys
from distutils.core import setup, Extension, Command

MINIMUM_CYTHON_VERSION = '0.20'
BASE_DIR = os.path.dirname(__file__)
PY2 = sys.version_info[0] == 2
DEBUG = False

def cmp(a, b):
    return (a > b) - (a < b)


class TestCommand(Command):
    description = 'Run packaged tests'
    user_options = []
    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        from tests import re2_test
        re2_test.testall()


def version_compare(version1, version2):
    def normalize(v):
        return [int(x) for x in re.sub(r'(\.0+)*$', '', v).split(".")]
    try:
        return cmp(normalize(version1), normalize(version2))
    except ValueError:  # raised by e.g. '0.24b0'
        return 1

cmdclass = {'test': TestCommand}

ext_files = []
if '--cython' in sys.argv or not os.path.exists('src/re2.cpp'):
    # Using Cython
    try:
        sys.argv.remove('--cython')
    except ValueError:
        pass
    from Cython.Compiler.Main import Version
    if version_compare(MINIMUM_CYTHON_VERSION, Version.version) > 0:
        raise ValueError("Cython is version %s, but needs to be at least %s." %
                         (Version.version, MINIMUM_CYTHON_VERSION))
    from Cython.Distutils import build_ext
    from Cython.Build import cythonize
    cmdclass['build_ext'] = build_ext
    use_cython = True
else:
    # Building from C
    ext_files.append("src/re2.cpp")
    use_cython = False


# Locate the re2 module
_re2_prefixes = [
    '/usr',
    '/usr/local',
    '/opt/',
]

for re2_prefix in _re2_prefixes:
    if os.path.exists(os.path.join(re2_prefix, "include", "re2")):
        break
else:
    re2_prefix = ""

def get_long_description():
    return ''

def get_authors():
    return ''

def main():
    os.environ['GCC_COLORS'] = 'auto'
    include_dirs = [os.path.join(re2_prefix, "include")] if re2_prefix else []
    libraries = ["re2"]
    library_dirs = [os.path.join(re2_prefix, "lib")] if re2_prefix else []
    runtime_library_dirs = [os.path.join(re2_prefix, "lib")
            ] if re2_prefix else []
    ext_modules = [
        Extension(
            "re2",
            sources=["src/re2.pyx" if use_cython else "src/re2.cpp"],
            language="c++",
            include_dirs=include_dirs,
            libraries=libraries,
            library_dirs=library_dirs,
            runtime_library_dirs=runtime_library_dirs,
            extra_compile_args=['-std=c++11', '-DPY2=%d' % PY2]
                + (['-g', '-O0'] if DEBUG else
                ['-O3', '-march=native', '-DNDEBUG']),
            extra_link_args=['-g'] if DEBUG else ['-DNDEBUG'],
        )]
    if use_cython:
        ext_modules = cythonize(
            ext_modules,
            language_level=3,
            annotate=True,
            compiler_directives={
                'embedsignature': True,
                'warn.unused': True,
                'warn.unreachable': True,
            })
    setup(
        name="re2",
        version="0.2.23",
        description="Python wrapper for Google's RE2 using Cython",
        long_description=get_long_description(),
        author=get_authors(),
        license="New BSD License",
        author_email = "mike@axiak.net",
        url = "http://github.com/axiak/pyre2/",
        ext_modules = ext_modules,
        cmdclass=cmdclass,
        classifiers = [
            'License :: OSI Approved :: BSD License',
            'Programming Language :: Cython',
            'Programming Language :: Python :: 2.6',
            'Programming Language :: Python :: 3.3',
            'Intended Audience :: Developers',
            'Topic :: Software Development :: Libraries :: Python Modules',
            ],
        )

if __name__ == '__main__':
    main()
